ok
<iframe src="https://insta.arni.fr/post.php" height="200" width="300" title="Iframe Example"></iframe>