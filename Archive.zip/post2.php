<?php

echo "Welcome to index page</br>";

    
header("refresh: 12600");

echo date('H:i:s Y-m-d');
  
exit;
?>






<?php

include 'config.php';

if (file_exists('json.json')) {

    $date = date("d/m"); 
    $modif = date ("d/m", filemtime('json.json'));
  
      if($date == $modif)
      {
          echo("ne rien faire");
      } else {
          
          $dir = '';
          array_map('unlink', glob("{$dir}*.json"));
          $url = "https://newsapi.org/v2/top-headlines?country=fr&apiKey=1b7c9fadeae845b7b31e395dbeae5048";
          
          $curl = curl_init($url);
          curl_setopt($curl, CURLOPT_URL, $url);
          curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
          
          $headers = array(
             "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.61 Safari/537.36",
          );
          curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
          //for debug only!
          curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
          curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
          
          $resp = curl_exec($curl);
          curl_close($curl);
          print($resp);
          file_put_contents("json.json",$resp);
      }
  
  } else {
  
    $dir = '';
    array_map('unlink', glob("{$dir}*.json"));
    $url = "https://newsapi.org/v2/top-headlines?country=fr&apiKey=1b7c9fadeae845b7b31e395dbeae5048";
    
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    
    $headers = array(
       "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.61 Safari/537.36",
    );
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    //for debug only!
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    
    $resp = curl_exec($curl);
    curl_close($curl);
    print($resp);
    file_put_contents("json.json",$resp);
  
  }
  
  function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


  //$numc = (rand(0,15));
  //$numc = $_GET['n'];

  $content22 = file_get_contents("log.txt");
  $un22 = "1";
  $numc= $content22+$un22; 





  $domain = 'insta.arni.fr';

  function saveIMAGE($urlIMAGE, $imageNAME) {

    $curl = curl_init();
    
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://url-to-screenshot.p.rapidapi.com/get?url=".$urlIMAGE."&height=600&mobile=0&allocated_time=2.0&width=600&base64=false",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => [
            "Accept: image/png",
            "X-RapidAPI-Host: url-to-screenshot.p.rapidapi.com",
            "X-RapidAPI-Key: d3ca977f24mshaaedc2c66cb4662p17648cjsnadd887eeacf3"
        ],
    ]);
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    file_put_contents($imageNAME,$response);
    
    }
    
    $string = generateRandomString();
    saveIMAGE("https://".$domain."/?step=first".$numc."","".$numc."".$string.".jpg");
    saveIMAGE("https://".$domain."/?step=second".$numc."","".$numc."".$string."-description.jpg");
    saveIMAGE("https://".$domain."/?step=third".$numc."","".$numc."".$string."-qr.jpg");


  $first = "https://".$domain."/".$numc."".$string.".jpg";
  $second = "https://".$domain."/".$numc."".$string."-description.jpg";
  $third = "https://".$domain."/".$numc."".$string."-qr.jpg";



  $json = file_get_contents("json.json");
  $arr = json_decode($json, true);
  $lien = $arr["articles"][$numc]["url"];



$curl = curl_init();
   
curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://graph.facebook.com/' . $api_version . '/' . $instagram_account_id . '/media?image_url=' . $first . '&is_carousel_item=true&access_token=' . $token . '',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST'
));

$un = curl_exec($curl);
curl_close($curl);
$arr1 = json_decode($un, true);
$first_ID = $arr1["id"];



$curl = curl_init();
   
curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://graph.facebook.com/' . $api_version . '/' . $instagram_account_id . '/media?image_url=' . $second . '&is_carousel_item=true&access_token=' . $token . '',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST'
));

$deux = curl_exec($curl);
curl_close($curl);
$arr2 = json_decode($deux, true);
$second_ID = $arr2["id"];



$curl = curl_init();
   
curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://graph.facebook.com/' . $api_version . '/' . $instagram_account_id . '/media?image_url=' . $third . '&is_carousel_item=true&access_token=' . $token . '',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST'
));

$trois = curl_exec($curl);
curl_close($curl);
$arr3 = json_decode($trois, true);
$third_ID = $arr3["id"];


    $curl = curl_init();
    $children = ''.$first_ID.'%2C'.$second_ID.'%2C'.$third_ID.'';
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://graph.facebook.com/' . $api_version . '/'.$instagram_account_id.'/media?caption='.$lien.'&media_type=CAROUSEL&children='.$children.'&access_token='.$token.'',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST'
    ));
    
    $upload = curl_exec($curl);
    curl_close($curl);
    $arr99 = json_decode($upload, true);
    $upload_ID = $arr99["id"];

    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://graph.facebook.com/' . $api_version . '/'.$instagram_account_id.'/media_publish?creation_id='.$upload_ID.'&access_token='.$token.'',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    
    $final = curl_exec($curl);

    curl_close($curl);
    
    $arrFINAL = json_decode($final, true);
    
    $final_id = $arrFINAL["id"];


    $dir = '';
    array_map('unlink', glob("{$dir}*.jpg"));
    

    if ($numc == 7){

        $myfile = fopen("log.txt", "w") or die("Unable to open file!");
        $txt = "0";
        fwrite($myfile, $txt);
        fclose($myfile);
    
        } else {

            $myfile = fopen("log.txt", "w") or die("Unable to open file!");
            $txt = $numc;
            fwrite($myfile, $txt);
            fclose($myfile);


        }
    

    echo 'yes!';
?>







